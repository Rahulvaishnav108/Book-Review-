import React, { useState } from "react";
import API from "../../api/axios";
import { useNavigate } from "react-router-dom";

export default function Login() {
  const [form, setForm] = useState({ email: "", password: "" });
  const nav = useNavigate();
  
  const handleSubmit = async (e) => {
    e.preventDefault();
    const { data } = await API.post("/auth/login", form);
    localStorage.setItem("token", data.token);
    nav("/");
  };

  return (
    <form onSubmit={handleSubmit}>
      <input type="email" required placeholder="Email"
        onChange={e => setForm(f => ({ ...f, email: e.target.value }))} />
      <input type="password" required placeholder="Password"
        onChange={e => setForm(f => ({ ...f, password: e.target.value }))} />
      <button type="submit">Login</button>
    </form>
  );
}
