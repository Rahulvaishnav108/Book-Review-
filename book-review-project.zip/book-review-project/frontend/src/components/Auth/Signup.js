import React, { useState } from "react";
import API from "../../api/axios";
import { useNavigate, Link } from "react-router-dom";

export default function Signup() {
  const [form, setForm] = useState({ username: "", email: "", password: "" });
  const nav = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();
    const { data } = await API.post("/auth/signup", form);
    localStorage.setItem("token", data.token);
    nav("/");
  };

  return (
    <div className="form-container">
      <form onSubmit={handleSubmit}>
        <h2>Sign Up</h2>
        <input type="text" required placeholder="Username"
          onChange={e => setForm(f => ({ ...f, username: e.target.value }))} />
        <input type="email" required placeholder="Email"
          onChange={e => setForm(f => ({ ...f, email: e.target.value }))} />
        <input type="password" required placeholder="Password"
          onChange={e => setForm(f => ({ ...f, password: e.target.value }))} />
        <button type="submit">Sign Up</button>
        <p style={{ textAlign: 'center', marginTop: '1rem' }}>
          Already have an account? <Link to="/login">Login</Link>
        </p>
      </form>
    </div>
  );
}
