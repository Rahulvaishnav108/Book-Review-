import React, { useEffect, useState } from "react";
import API from "../../api/axios";
import { Link } from "react-router-dom";

export default function BookList() {
  const [books, setBooks] = useState([]);
  const [page, setPage] = useState(1);
  const [pages, setPages] = useState(1);

  useEffect(() => {
    API.get(`/books?page=${page}`).then(res => {
      setBooks(res.data.books);
      setPages(res.data.pages);
    });
  }, [page]);

  return (
    <div>
      <div className="book-list">
        {books.map(book => (
          <div key={book._id} className="book-card">
            <Link to={`/books/${book._id}`}>
              <h3>{book.title} by {book.author}</h3>
            </Link>
            <p>Average Rating: {book.avgRating?.toFixed(2) || 'No ratings yet'}</p>
          </div>
        ))}
      </div>
      <div className="pagination">
        {Array(pages).fill(null).map((_, i) => (
          <button
            key={i}
            className={page === i + 1 ? 'active' : ''}
            onClick={() => setPage(i + 1)}
          >
            {i + 1}
          </button>
        ))}
      </div>
    </div>
  );
}
