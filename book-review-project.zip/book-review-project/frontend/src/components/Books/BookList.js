import React, { useEffect, useState } from "react";
import API from "../../api/axios";
import { Link } from "react-router-dom";

export default function BookList() {
  const [books, setBooks] = useState([]);
  const [page, setPage] = useState(1);
  const [pages, setPages] = useState(1);

  useEffect(() => {
    API.get(`/books?page=${page}`).then(res => {
      setBooks(res.data.books);
      setPages(res.data.pages);
    });
  }, [page]);

  return (
    <div>
      <Link to="/books/add">Add Book</Link>
      {books.map(book => (
        <div key={book._id}>
          <Link to={`/books/${book._id}`}>
            <h3>{book.title} by {book.author}</h3></Link>
          <p>Average Rating: {book.avgRating?.toFixed(2)}</p>
        </div>
      ))}
      <div>
        {Array(pages).fill(null).map((_, i) => <button key={i} onClick={() => setPage(i + 1)}>{i + 1}</button>)}
      </div>
    </div>
  );
}
