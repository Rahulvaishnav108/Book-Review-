import React, { useEffect, useState } from "react";
import API from "../../api/axios";
import { useParams, Link } from "react-router-dom";
import ReviewForm from "./ReviewForm";

export default function BookPage() {
  const { id } = useParams();
  const [book, setBook] = useState(null);

  useEffect(() => {
    API.get(`/books/${id}`).then(res => setBook(res.data));
  }, [id]);

  if (!book) return <div>Loading...</div>;
  return (
    <div>
      <h1>{book.title} by {book.author}</h1>
      <p>{book.description}</p>
      <h2>Reviews ({book.reviews?.length || 0})</h2>
      <ul>
        {book.reviews?.map((r, i) => (
          <li key={i}>
            {r.user?.username || "Anonymous"} rated {r.rating}/5: "{r.comment}"
          </li>
        ))}
      </ul>
      <h3>Average Rating: {book.avgRating?.toFixed(2)}</h3>
      <ReviewForm bookId={id} />
      <Link to={`/books/${id}/edit`}>Edit</Link>
    </div>
  );
}
