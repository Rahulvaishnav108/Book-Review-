import React, { useState, useEffect } from "react";
import API from "../../api/axios";
import { useNavigate, useParams } from "react-router-dom";

export default function BookForm() {
  const { id } = useParams();
  const nav = useNavigate();
  const [form, setForm] = useState({ title: "", author: "", description: "" });

  useEffect(() => {
    if (id) {
      API.get(`/books/${id}`).then(r =>
        setForm({ title: r.data.title, author: r.data.author, description: r.data.description || "" })
      );
    }
  }, [id]);

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (id) await API.put(`/books/${id}`, form);
    else await API.post("/books", form);
    nav("/");
  };

  return (
    <form onSubmit={handleSubmit}>
      <input type="text" required placeholder="Title" value={form.title}
        onChange={e => setForm(f => ({ ...f, title: e.target.value }))} />
      <input type="text" required placeholder="Author" value={form.author}
        onChange={e => setForm(f => ({ ...f, author: e.target.value }))} />
      <textarea placeholder="Description" value={form.description}
        onChange={e => setForm(f => ({ ...f, description: e.target.value }))} />
      <button type="submit">{id ? "Update" : "Add"} Book</button>
    </form>
  );
}
