import React, { useState } from "react";
import API from "../../api/axios";

export default function ReviewForm({ bookId }) {
  const [form, setForm] = useState({ rating: "", comment: "" });
  const [success, setSuccess] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    await API.post(`/books/${bookId}/reviews`, form);
    setSuccess(true);
    setForm({ rating: "", comment: "" });
    window.location.reload();
  };

  return (
    <form onSubmit={handleSubmit}>
      <input type="number" required min="1" max="5" placeholder="Rating (1-5)"
        value={form.rating}
        onChange={e => setForm(f => ({ ...f, rating: e.target.value }))} />
      <input type="text" placeholder="Comment"
        value={form.comment}
        onChange={e => setForm(f => ({ ...f, comment: e.target.value }))} />
      <button type="submit">Add Review</button>
      {success && <div>Review added!</div>}
    </form>
  );
}
