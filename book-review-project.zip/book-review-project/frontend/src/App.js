import React from "react";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import Header from "./components/Header";
import Signup from "./components/Auth/Signup";
import Login from "./components/Auth/Login";
import BookList from "./components/Books/BookList";
import BookPage from "./components/Books/BookPage";
import BookForm from "./components/Books/BookForm";

function App() {
  return (
    <BrowserRouter>
      <div className="app-container">
        <Header />
        <main className="main-content">
          <Routes>
            <Route path="/signup" element={<Signup />} />
            <Route path="/login" element={<Login />} />
            <Route path="/" element={<BookList />} />
            <Route path="/books/add" element={<BookForm />} />
            <Route path="/books/:id" element={<BookPage />} />
            <Route path="/books/:id/edit" element={<BookForm />} />
          </Routes>
        </main>
      </div>
    </BrowserRouter>
  );
}
export default App;
