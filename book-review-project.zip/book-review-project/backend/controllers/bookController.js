const Book = require("../models/Book");
const Review = require("../models/Review");

// Create Book
exports.createBook = async (req, res) => {
  try {
    const { title, author, description } = req.body;
    const book = new Book({ title, author, description, createdBy: req.user.id });
    await book.save();
    res.status(201).json(book);
  } catch (err) {
    res.status(500).send("Error creating book");
  }
};

// List Books (with pagination)
exports.getBooks = async (req, res) => {
  const page = parseInt(req.query.page) || 1;
  const limit = 5;
  const skip = (page - 1) * limit;
  const books = await Book.find().skip(skip).limit(limit).sort({ createdAt: -1 });
  const total = await Book.countDocuments();
  res.json({ books, total, pages: Math.ceil(total / limit) });
};

// Get Book (with reviews)
exports.getBook = async (req, res) => {
  try {
    const book = await Book.findById(req.params.id);
    if (!book) return res.status(404).json({ msg: "Book not found" });
    const reviews = await Review.find({ book: book._id }).populate("user", "username");
    const avgRating = reviews.length ? reviews.reduce((acc, r) => acc + r.rating, 0) / reviews.length : 0;
    res.json({ ...book.toObject(), reviews, avgRating });
  } catch (err) {
    res.status(404).json({ msg: "Book not found" });
  }
};

// Update Book
exports.updateBook = async (req, res) => {
  try {
    const book = await Book.findOneAndUpdate(
      { _id: req.params.id, createdBy: req.user.id },
      req.body,
      { new: true }
    );
    if (!book) return res.status(404).json({ msg: "Book not found or unauthorized" });
    res.json(book);
  } catch (err) {
    res.status(500).send("Error updating book");
  }
};

// Delete Book
exports.deleteBook = async (req, res) => {
  try {
    const book = await Book.findOneAndDelete({ _id: req.params.id, createdBy: req.user.id });
    if (!book) return res.status(404).json({ msg: "Book not found or unauthorized" });
    await Review.deleteMany({ book: req.params.id });
    res.json({ msg: "Deleted" });
  } catch (err) {
    res.status(500).send("Error deleting book");
  }
};
