const Review = require("../models/Review");
const Book = require("../models/Book");

exports.addReview = async (req, res) => {
  try {
    const { rating, comment } = req.body;
    const review = new Review({
      user: req.user.id,
      book: req.params.bookId,
      rating,
      comment
    });
    await review.save();

    // Update avgRating on Book
    const reviews = await Review.find({ book: req.params.bookId });
    const avgRating = reviews.reduce((acc, r) => acc + r.rating, 0) / reviews.length;
    await Book.findByIdAndUpdate(req.params.bookId, { avgRating });

    res.status(201).json(review);
  } catch (err) {
    res.status(500).send("Error adding review");
  }
};
