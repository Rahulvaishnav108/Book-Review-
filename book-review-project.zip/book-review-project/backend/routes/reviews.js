const express = require('express');
const router = express.Router({ mergeParams: true });
const auth = require('../middleware/authMiddleware');
const reviewCtrl = require('../controllers/reviewController');

router.post('/', auth, reviewCtrl.addReview);

module.exports = router;
