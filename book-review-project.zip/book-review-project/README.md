# Book Review Project

This is a full-stack book review application built with React (frontend) and Express.js with MongoDB (backend). Users can sign up, log in, add books, and leave reviews.

## Prerequisites
- **Node.js** (version 14 or higher) and **npm** installed on your system.
- **MongoDB** installed and running locally (or a cloud instance like MongoDB Atlas).

## Project Structure
- **backend/**: Express server, API routes, database models, authentication.
- **frontend/**: React app with components for books, reviews, and user auth.

## Setup Instructions

### 1. Clone or Navigate to the Project
Navigate to the project directory:
```
cd "C:\Users\rahul\OneDrive\Desktop\Live_kit Alpha\book-review-project"
```

### 2. Backend Setup
1. Navigate to the backend directory:
   ```
   cd backend
   ```

2. Install dependencies:
   ```
   npm install
   ```

3. Create a `.env` file in the `backend/` directory with the following:
   ```
   MONGO_URI=mongodb://localhost:27017/bookreview  # Update if using a different MongoDB URI
   JWT_SECRET=your_jwt_secret_key_here  # Replace with a secure random string
   PORT=5000  # Optional, defaults to 5000
   ```

4. Start the backend server:
   ```
   npm run dev  # For development (with nodemon)
   # or
   npm start    # For production
   ```
   - Server runs on `http://localhost:5000`.
   - Ensure MongoDB connects (check console for "MongoDB Connected").

### 3. Frontend Setup
1. Open a new terminal and navigate to the frontend directory:
   ```
   cd frontend
   ```

2. Install dependencies:
   ```
   npm install
   ```

3. Start the React app:
   ```
   npm start
   ```
   - App runs on `http://localhost:3000`.
   - It connects to the backend API at `http://localhost:5000/api`.

### 4. Usage
- Visit `http://localhost:3000` in your browser.
- Sign up or log in to add books and reviews.
- Test API endpoints with tools like Postman if needed.

## API Endpoints
- `POST /api/auth/register` - User registration
- `POST /api/auth/login` - User login
- `GET /api/books` - Get all books
- `POST /api/books` - Add a new book (authenticated)
- `GET /api/books/:id` - Get book details
- `POST /api/books/:id/reviews` - Add a review (authenticated)

## Technologies Used
- **Frontend**: React, React Router, Axios
- **Backend**: Express.js, MongoDB (Mongoose), JWT, bcrypt
- **Other**: CORS, dotenv

## Notes
- JWT tokens are stored in localStorage for authentication.
- Ensure both backend and frontend are running for full functionality.
- For production deployment, build the frontend and configure the backend accordingly.

If you encounter issues, check the console logs or verify your `.env` configuration.
